package com.example.trackone;

import android.app.ProgressDialog;
import android.content.Intent;
import android.net.Uri;
import android.support.annotation.NonNull;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

public class InviteCodeActivity extends AppCompatActivity {

    String name, email, password, date, isSharing, code;
    Uri imageUri;
    TextView inviteCode;
    FirebaseAuth auth;
    FirebaseUser user;
    DatabaseReference reference;
    ProgressDialog dialog;
    String userID;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_invite_code);

        inviteCode = findViewById(R.id.inviteCode);
        auth = FirebaseAuth.getInstance();
        dialog = new ProgressDialog(this);
        reference = FirebaseDatabase.getInstance().getReference().getRoot();

        Intent myIntent = getIntent();
        if (myIntent != null) {
            //Storing Email and Password
            name = myIntent.getStringExtra("name");
            email = myIntent.getStringExtra("email");
            password = myIntent.getStringExtra("password");
            date = myIntent.getStringExtra("date");
            isSharing = myIntent.getStringExtra("isSharing");
            code = myIntent.getStringExtra("code");
            imageUri = myIntent.getParcelableExtra("imageUri");
        }
        inviteCode.setText(code);
    }

    @Override
    protected void onStart() {
        super.onStart();



    }

    public void registerUser (View view) {

        dialog.setMessage("Please wait while we're setting things up for you");
        dialog.show();

        auth.signInWithEmailAndPassword(email, password)
                .addOnCompleteListener(new OnCompleteListener<AuthResult>() {
                    @Override
                    public void onComplete(@NonNull Task<AuthResult> task) {
                        if (task.isSuccessful()) {
                            //Storing user Data in Database

                            CreateUser createUser = new CreateUser(name, email, password,  code, "false", date,"na", "na", "na");

                            user = auth.getCurrentUser();
                            userID = user.getUid();

                            reference.child(userID).setValue(createUser)
                                    .addOnCompleteListener(new OnCompleteListener<Void>() {
                                        @Override
                                        public void onComplete(@androidx.annotation.NonNull Task<Void> task) {
                                            if (task.isSuccessful()) {
                                                dialog.dismiss();

                                                Toast.makeText(InviteCodeActivity.this, "User Registered Successfully", Toast.LENGTH_SHORT).show();
                                            }
                                            else {
                                                dialog.dismiss();
                                                Toast.makeText(InviteCodeActivity.this, "Oops! Something went wrong", Toast.LENGTH_SHORT).show();
                                            }
                                        }
                                    })
                        }
                        else {
                            //Toast Failure Message message
                        }
                    }
                });


    }
}
